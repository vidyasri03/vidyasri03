package question;
import java.util.Scanner;
import process.process_details;
public class example {

	int size;
	process.process_details[] processes;
	public example() {
		// TODO Auto-generated constructor stub
		System.out.println("Enter the number of processes");
		Scanner sc = new Scanner(System.in);
		this.size = sc.nextInt();
		processes = new process.process_details[size];
		read_data();
	}
	public void read_data()
	{
		for(int i =0; i< size; i++)
		{
			processes[i] = new process.process_details();
			processes[i].process_number = i;
		}
	}
	public void display()
	{
		System.out.println("Table:");
		System.out.println("____________________________________________________");
		System.out.println("|  process number |   AT   |   BT   |   Priority   |");
		System.out.println("|_________________|________|________|______________|");
		for(int i = 0; i< size; i++)
		{
			if(processes[i].process_number /10 ==0 )
				System.out.print("|       0"+processes[i].process_number+"        |");
			else
				System.out.print("|        "+processes[i].process_number+"        |");
			if(processes[i].arrival_time /10 ==0 )
				System.out.print("   0"+processes[i].arrival_time+"   |");
			else
				System.out.print("   "+processes[i].arrival_time+"   |");
			if(processes[i].burst_time /10 ==0 )
				System.out.print("   0"+processes[i].burst_time+"   |");
			else
				System.out.print("   "+processes[i].burst_time+"   |");
			if(processes[i].priority /10 ==0 )
				System.out.print("      0"+processes[i].priority+"      |");
			else
				System.out.print("      "+processes[i].priority+"      |");
			System.out.println();
			System.out.println("|_________________|________|________|______________|");
		}
		
	}

}
