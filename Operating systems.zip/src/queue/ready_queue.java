package queue;
import process.process_details;
public class ready_queue {//priority based
	int ready_queue_size;
	int front, rear;
	process.process_details[] ready_process_array;
	public ready_queue(int n) {
		// TODO Auto-generated constructor stub
		ready_queue_size = n;
		front = rear = -1;
		ready_process_array = new process.process_details[ready_queue_size];
	}
	void enq(process.process_details p)
	{
		if(front ==  -1)
		{
			front = rear = 0;
		}
		else 
		{
			for(int i = 0; i<= rear; i++)
			{
				if(p.priority >= ready_process_array[i].priority)//not done
				{
					break;
				}
			}
		}
		ready_process_array[rear]= p;
	}
	void deq()
	{
		if(front == -1)
			System.out.println("Error no processes in ready queue");
		else
		{
		for(int i = 0; i< rear; i++)//for making sure there is no problem with the front rear
		{
			ready_process_array[i]= ready_process_array[i+1];
		}
		rear--;
		}
		
	}
}
