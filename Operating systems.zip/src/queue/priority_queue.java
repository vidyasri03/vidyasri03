package queue;
import process.process_details;
public class priority_queue {
	process.process_details[] rr_processes
	
	public priority_queue() {
		// TODO Auto-generated constructor stub
	}

}
