package Main;
import question.example;
public class implement {
		public static void main(String[] args)
		{
			example e1 = new example();
			e1.display();
		}
}