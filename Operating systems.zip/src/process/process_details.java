package process;
import java.util.*;
public class process_details {

	public int arrival_time;
	public int burst_time;
	public int priority;
	public int process_number;
	public process_details() {
		// TODO Auto-generated constructor stub
		System.out.println("Arrival time");
		Scanner sc= new Scanner(System.in);
		this.arrival_time = sc.nextInt();
		System.out.println("Burst time");
		this.burst_time = sc.nextInt();
		System.out.println("Priority");
		this.priority = sc.nextInt();
	}

}
