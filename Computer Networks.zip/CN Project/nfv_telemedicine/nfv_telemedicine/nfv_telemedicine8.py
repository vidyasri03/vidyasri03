import matplotlib.pyplot as plt
import random
import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
import networkx as nx

# Network Setup and Visualization
def setup_network():
    graph = nx.Graph()
    graph.add_weighted_edges_from([
        ('Hospital_A', 'Cell_1', 2),
        ('Cell_1', 'Cell_2', 3),
        ('Cell_2', 'Cell_3', 1),
        ('Cell_3', 'Cell_4', 4),
        ('Cell_4', 'Cell_5', 2),
        ('Cell_5', 'Cell_6', 3),
        ('Cell_6', 'Cell_7', 1),
        ('Cell_7', 'Cell_8', 2),
        ('Cell_8', 'User', 5),
        ('Hospital_A', 'Cell_2', 4),
        ('Cell_1', 'Cell_6', 3),
        ('Cell_2', 'Cell_7', 5),
        ('Cell_3', 'Cell_5', 2),
        ('Cell_4', 'Cell_6', 1),
        ('Cell_5', 'Cell_8', 4)
    ])
    return graph

# SDN Controller for Dynamic Path Management with 5G Network Slicing
class SDNController:
    def __init__(self, graph):
        self.graph = graph

    def get_dynamic_optimal_path(self, source, target, slice_type="telemedicine"):
        # Adjust the path based on network conditions and slice type
        modified_graph = self.adjust_for_congestion(slice_type)
        return nx.dijkstra_path(modified_graph, source=source, target=target, weight='weight')

    def adjust_for_congestion(self, slice_type):
        # Simulate congestion by randomly increasing weights on edges based on slice type
        modified_graph = self.graph.copy()

        for u, v, data in modified_graph.edges(data=True):
            congestion_level = random.randint(0, 100)
            latency = random.randint(10, 100)
            bandwidth = random.randint(100, 1000)
            jitter = random.randint(5, 20)

            if slice_type == "telemedicine":
                data['weight'] += random.choice([0, 1, 2]) + (latency // 10)
            elif slice_type == "healthcare":
                data['weight'] += random.choice([0, 1]) + (congestion_level // 10)
            elif slice_type == "video" or slice_type == "voip":
                data['weight'] += random.choice([0, 3]) + (bandwidth // 100)
                data['weight'] += jitter // 5
            elif slice_type == "urlcc":
                data['weight'] += random.choice([0, 0]) + (latency // 20)
                if u == 'Cell_1' and v == 'Cell_2':
                    data['weight'] = 1
                if u == 'Cell_7' and v == 'Cell_8':
                    data['weight'] = 1

        return modified_graph

# AES-GCM Secure Transmission
def encrypt_data(data, key):
    iv = os.urandom(12)
    cipher = Cipher(algorithms.AES(key), modes.GCM(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    padded_data = pad_data(data)
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()
    return ciphertext, iv, encryptor.tag

def decrypt_data(ciphertext, key, iv, tag):
    cipher = Cipher(algorithms.AES(key), modes.GCM(iv, tag), backend=default_backend())
    decryptor = cipher.decryptor()
    decrypted_data = decryptor.update(ciphertext) + decryptor.finalize()
    return unpad_data(decrypted_data)

def pad_data(data):
    padder = padding.PKCS7(128).padder()
    return padder.update(data.encode()) + padder.finalize()

def unpad_data(data):
    unpadder = padding.PKCS7(128).unpadder()
    return unpadder.update(data) + unpadder.finalize()

# Simulating Mobility Management with Step Count and QoS
def simulate_mobility(graph, path, slice_type):
    steps = len(path) - 1
    print(f"\nNumber of steps for mobility management: {steps}")
    print(f"Simulating Mobility for Slice: {slice_type}...")
    
    latency = random.randint(10, 100)
    bandwidth = random.randint(100, 1000)
    congestion = random.randint(0, 100)
    jitter = random.randint(5, 20)
    print(f"QoS for {slice_type}: Latency={latency}ms, Bandwidth={bandwidth} Mbps, Service Load={congestion}%, Jitter={jitter}ms")
    
    for step, (current, next_node) in enumerate(zip(path, path[1:]), start=1):
        print(f"Step {step}: Moving from {current} to {next_node}")
    return steps, latency, bandwidth, congestion, jitter

# Simulation of Different Scenarios
def simulate():
    graph = setup_network()
    sdn_controller = SDNController(graph)
    source = 'Hospital_A'
    target = 'User'

    # Scenario 1: Mobile Patient in Rural Areas (Telemedicine Slice)
    print("\n=== Scenario 1: Mobile Patient in Rural Areas (Telemedicine Slice) ===")
    path_telemedicine = sdn_controller.get_dynamic_optimal_path(source, target, slice_type="telemedicine")
    print(f"Optimal Path for Telemedicine: {path_telemedicine}")
    steps_telemedicine, latency_telemedicine, bandwidth_telemedicine, load_telemedicine, jitter_telemedicine = simulate_mobility(graph, path_telemedicine, slice_type="Telemedicine")
    print(f"Total steps for Scenario 1: {steps_telemedicine}")

    # Bar chart for Scenario 1
    plt.figure(figsize=(8, 6))
    metrics_telemedicine = [steps_telemedicine, latency_telemedicine, bandwidth_telemedicine, load_telemedicine, jitter_telemedicine]
    labels_telemedicine = ['Steps', 'Latency (ms)', 'Bandwidth (Mbps)', 'Service Load (%)', 'Jitter (ms)']
    plt.bar(labels_telemedicine, metrics_telemedicine, color='skyblue')
    plt.title('Telemedicine Slice QoS Metrics')
    plt.ylabel('Values')
    plt.show()

    # Scenario 2: Ambulance-Based Emergency Healthcare Services (URLCC Slice)
    print("\n=== Scenario 2: Ambulance-Based Emergency Healthcare Services (URLCC Slice) ===")
    path_urlcc = sdn_controller.get_dynamic_optimal_path(source, target, slice_type="urlcc")
    print(f"Optimal Path for URLLC-based Ambulance Healthcare Communication: {path_urlcc}")
    steps_urlcc, latency_urlcc, bandwidth_urlcc, load_urlcc, jitter_urlcc = simulate_mobility(graph, path_urlcc, slice_type="URLCC")
    print(f"Total steps for Scenario 2 with URLLC: {steps_urlcc}")

    # Bar chart for Scenario 2
    plt.figure(figsize=(8, 6))
    metrics_urlcc = [steps_urlcc, latency_urlcc, bandwidth_urlcc, load_urlcc, jitter_urlcc]
    labels_urlcc = ['Steps', 'Latency (ms)', 'Bandwidth (Mbps)', 'Service Load (%)', 'Jitter (ms)']
    plt.bar(labels_urlcc, metrics_urlcc, color='skyblue')
    plt.title('URLCC Slice QoS Metrics')
    plt.ylabel('Values')
    plt.show()

    # Secure Data Transmission for Scenario 2
    data = "Critical IoT Data: Ambulance speed 80 km/h, Patient heart rate 90 BPM"
    key = os.urandom(32)
    ciphertext, iv, tag = encrypt_data(data, key)
    print("\nSecure Transmission Data:")
    print(f"Encrypted Data: {ciphertext}")
    decrypted_data = decrypt_data(ciphertext, key, iv, tag)
    print(f"Decrypted Data: {decrypted_data.decode()}")

    # Scenario 3: Hospital-Centric Telemedicine for Urban Mobility (VoIP Slice)
    print("\n=== Scenario 3: Hospital-Centric Telemedicine for Urban Mobility (VoIP Slice) ===")
    path_voip = sdn_controller.get_dynamic_optimal_path(source, target, slice_type="voip")
    print(f"Optimal Path for VoIP-Based Urban Telemedicine: {path_voip}")
    steps_voip, latency_voip, bandwidth_voip, load_voip, jitter_voip = simulate_mobility(graph, path_voip, slice_type="VoIP")
    print(f"Total steps for Scenario 3: {steps_voip}")

    # Bar chart for Scenario 3
    plt.figure(figsize=(8, 6))
    metrics_voip = [steps_voip, latency_voip, bandwidth_voip, load_voip, jitter_voip]
    labels_voip = ['Steps', 'Latency (ms)', 'Bandwidth (Mbps)', 'Service Load (%)', 'Jitter (ms)']
    plt.bar(labels_voip, metrics_voip, color='skyblue')
    plt.title('VoIP Slice QoS Metrics')
    plt.ylabel('Values')
    plt.show()

if __name__ == "__main__":
    simulate()
