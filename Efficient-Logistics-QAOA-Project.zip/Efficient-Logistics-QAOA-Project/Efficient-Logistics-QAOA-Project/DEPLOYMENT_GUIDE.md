# Deployment Guide - Quantum Logistics Optimizer

## 📋 Table of Contents
1. [Streamlit Cloud (Easiest)](#1-streamlit-cloud-easiest)
2. [Heroku](#2-heroku)
3. [AWS EC2](#3-aws-ec2)
4. [Docker Deployment](#4-docker-deployment)
5. [Azure App Service](#5-azure-app-service)
6. [Google Cloud Run](#6-google-cloud-run)

---

## 1. Streamlit Cloud (Easiest) ⭐ Recommended

### Prerequisites
- GitHub account
- Streamlit Cloud account (free at streamlit.io)

### Steps

#### A. Prepare Your Repository

1. **Create `.streamlit/config.toml`** (if not exists):
```bash
mkdir .streamlit
```

Create `.streamlit/config.toml`:
```toml
[theme]
primaryColor = "#A23B72"
backgroundColor = "#FFFFFF"
secondaryBackgroundColor = "#F0F2F6"
textColor = "#262730"
font = "sans serif"

[server]
headless = true
port = 8501
enableCORS = false
```

2. **Create `packages.txt`** (for system dependencies):
```txt
build-essential
```

3. **Verify `requirements.txt`** is up to date (already exists)

4. **Push to GitHub**:
```bash
git init
git add .
git commit -m "Prepare for Streamlit Cloud deployment"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

#### B. Deploy on Streamlit Cloud

1. Go to [share.streamlit.io](https://share.streamlit.io)
2. Sign in with GitHub
3. Click "New app"
4. Select your repository
5. Set:
   - **Main file path**: `frontend/streamlit_app.py`
   - **Python version**: 3.9 or higher
6. Click "Deploy"
7. Wait 5-10 minutes for deployment

**Your app will be live at**: `https://YOUR_USERNAME-YOUR_REPO.streamlit.app`

---

## 2. Heroku

### Prerequisites
- Heroku account
- Heroku CLI installed

### Steps

#### A. Create Heroku Configuration Files

1. **Create `Procfile`**:
```bash
web: sh setup.sh && streamlit run frontend/streamlit_app.py --server.port=$PORT --server.address=0.0.0.0
```

2. **Create `setup.sh`**:
```bash
mkdir -p ~/.streamlit/

echo "\
[server]\n\
headless = true\n\
port = $PORT\n\
enableCORS = false\n\
\n\
" > ~/.streamlit/config.toml
```

3. **Make setup.sh executable**:
```bash
chmod +x setup.sh
```

4. **Create `runtime.txt`**:
```txt
python-3.9.18
```

#### B. Deploy to Heroku

```bash
# Login to Heroku
heroku login

# Create Heroku app
heroku create your-quantum-logistics-app

# Add buildpack
heroku buildpacks:set heroku/python

# Deploy
git add .
git commit -m "Heroku deployment configuration"
git push heroku main

# Open your app
heroku open
```

**Your app will be at**: `https://your-quantum-logistics-app.herokuapp.com`

---

## 3. AWS EC2

### Prerequisites
- AWS account
- EC2 instance (t2.medium or larger recommended)
- SSH key pair

### Steps

#### A. Launch EC2 Instance

1. Go to AWS Console → EC2
2. Launch Instance:
   - **AMI**: Ubuntu Server 22.04 LTS
   - **Instance Type**: t2.medium (2 vCPU, 4GB RAM)
   - **Security Group**: Allow ports 22 (SSH) and 8501 (Streamlit)
3. Download key pair

#### B. Connect and Setup

```bash
# Connect to instance
ssh -i your-key.pem ubuntu@your-ec2-ip

# Update system
sudo apt update && sudo apt upgrade -y

# Install Python and pip
sudo apt install python3-pip python3-venv -y

# Clone your repository
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git
cd YOUR_REPO

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Install screen for background running
sudo apt install screen -y
```

#### C. Run Application

```bash
# Start screen session
screen -S streamlit

# Run Streamlit
streamlit run frontend/streamlit_app.py --server.port=8501 --server.address=0.0.0.0

# Detach from screen: Press Ctrl+A, then D
```

**Access at**: `http://your-ec2-ip:8501`

#### D. Setup as Service (Optional)

Create `/etc/systemd/system/streamlit.service`:
```ini
[Unit]
Description=Streamlit Quantum Logistics App
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/YOUR_REPO
Environment="PATH=/home/ubuntu/YOUR_REPO/venv/bin"
ExecStart=/home/ubuntu/YOUR_REPO/venv/bin/streamlit run frontend/streamlit_app.py --server.port=8501 --server.address=0.0.0.0
Restart=always

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable streamlit
sudo systemctl start streamlit
sudo systemctl status streamlit
```

---

## 4. Docker Deployment

### Prerequisites
- Docker installed
- Docker Hub account (optional)

### Steps

#### A. Verify Dockerfile Exists

Your project already has `Dockerfile.streamlit`. Verify it:

```dockerfile
FROM python:3.9-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements
COPY requirements.txt .

# Install Python dependencies
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Expose port
EXPOSE 8501

# Run Streamlit
CMD ["streamlit", "run", "frontend/streamlit_app.py", "--server.port=8501", "--server.address=0.0.0.0"]
```

#### B. Build and Run

```bash
# Build Docker image
docker build -f Dockerfile.streamlit -t quantum-logistics:latest .

# Run container
docker run -p 8501:8501 quantum-logistics:latest

# Or run in background
docker run -d -p 8501:8501 --name quantum-app quantum-logistics:latest
```

**Access at**: `http://localhost:8501`

#### C. Push to Docker Hub (Optional)

```bash
# Login to Docker Hub
docker login

# Tag image
docker tag quantum-logistics:latest YOUR_USERNAME/quantum-logistics:latest

# Push to Docker Hub
docker push YOUR_USERNAME/quantum-logistics:latest
```

#### D. Deploy with Docker Compose

Create `docker-compose.yml`:
```yaml
version: '3.8'

services:
  streamlit:
    build:
      context: .
      dockerfile: Dockerfile.streamlit
    ports:
      - "8501:8501"
    volumes:
      - ./data:/app/data
      - ./results:/app/results
    restart: unless-stopped
    environment:
      - PYTHONUNBUFFERED=1
```

Run:
```bash
docker-compose up -d
```

---

## 5. Azure App Service

### Prerequisites
- Azure account
- Azure CLI installed

### Steps

```bash
# Login to Azure
az login

# Create resource group
az group create --name quantum-logistics-rg --location eastus

# Create App Service plan
az appservice plan create \
  --name quantum-logistics-plan \
  --resource-group quantum-logistics-rg \
  --sku B1 \
  --is-linux

# Create web app
az webapp create \
  --resource-group quantum-logistics-rg \
  --plan quantum-logistics-plan \
  --name your-quantum-logistics-app \
  --runtime "PYTHON|3.9"

# Configure startup command
az webapp config set \
  --resource-group quantum-logistics-rg \
  --name your-quantum-logistics-app \
  --startup-file "streamlit run frontend/streamlit_app.py --server.port=8000 --server.address=0.0.0.0"

# Deploy from local Git
az webapp deployment source config-local-git \
  --name your-quantum-logistics-app \
  --resource-group quantum-logistics-rg

# Get deployment URL
az webapp deployment list-publishing-credentials \
  --name your-quantum-logistics-app \
  --resource-group quantum-logistics-rg

# Push code
git remote add azure <deployment-url>
git push azure main
```

**Your app will be at**: `https://your-quantum-logistics-app.azurewebsites.net`

---

## 6. Google Cloud Run

### Prerequisites
- Google Cloud account
- gcloud CLI installed

### Steps

#### A. Setup Google Cloud

```bash
# Login
gcloud auth login

# Set project
gcloud config set project YOUR_PROJECT_ID

# Enable required APIs
gcloud services enable run.googleapis.com
gcloud services enable containerregistry.googleapis.com
```

#### B. Build and Deploy

```bash
# Build container
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/quantum-logistics

# Deploy to Cloud Run
gcloud run deploy quantum-logistics \
  --image gcr.io/YOUR_PROJECT_ID/quantum-logistics \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8501 \
  --memory 2Gi \
  --cpu 2
```

**Your app will be at**: The URL provided after deployment

---

## 🔧 Environment Variables

For production deployments, create `.env` file:

```env
# Application Settings
APP_NAME=Quantum Logistics Optimizer
DEBUG=False

# Streamlit Settings
STREAMLIT_SERVER_PORT=8501
STREAMLIT_SERVER_ADDRESS=0.0.0.0
STREAMLIT_SERVER_HEADLESS=true

# Optimization Settings
DEFAULT_TIME_LIMIT=30
DEFAULT_CIRCUIT_DEPTH=2
DEFAULT_SHOTS=1024
```

---

## 📊 Resource Requirements

### Minimum Requirements:
- **CPU**: 2 cores
- **RAM**: 4GB
- **Storage**: 10GB
- **Network**: 1Mbps

### Recommended for Production:
- **CPU**: 4 cores
- **RAM**: 8GB
- **Storage**: 20GB
- **Network**: 10Mbps

---

## 🔒 Security Considerations

1. **Environment Variables**: Never commit sensitive data
2. **HTTPS**: Use SSL certificates in production
3. **Authentication**: Add user authentication if needed
4. **Rate Limiting**: Implement API rate limiting
5. **Firewall**: Configure proper security groups

---

## 🧪 Testing Deployment

After deployment, test these endpoints:

```bash
# Health check
curl https://your-app-url/

# Test with sample data
# Use the web interface to:
1. Load sample data
2. Run classical solver
3. Run quantum solver
4. View results
```

---

## 📈 Monitoring

### Streamlit Cloud:
- Built-in analytics dashboard
- View logs in Streamlit Cloud console

### Heroku:
```bash
heroku logs --tail
heroku ps
```

### AWS:
- CloudWatch for logs and metrics
- Set up alarms for CPU/Memory

### Docker:
```bash
docker logs quantum-app
docker stats quantum-app
```

---

## 🚀 Quick Deployment Comparison

| Platform | Difficulty | Cost | Setup Time | Best For |
|----------|-----------|------|------------|----------|
| **Streamlit Cloud** | ⭐ Easy | Free | 5 min | Quick demos, prototypes |
| **Heroku** | ⭐⭐ Medium | $7/mo | 15 min | Small apps, testing |
| **Docker** | ⭐⭐⭐ Medium | Varies | 20 min | Flexibility, portability |
| **AWS EC2** | ⭐⭐⭐⭐ Hard | $20/mo | 30 min | Full control, scaling |
| **Azure** | ⭐⭐⭐ Medium | $15/mo | 25 min | Enterprise, Microsoft stack |
| **GCP Cloud Run** | ⭐⭐⭐ Medium | Pay-per-use | 20 min | Serverless, auto-scaling |

---

## 🎯 Recommended Deployment Path

### For Development/Demo:
1. **Streamlit Cloud** (easiest, free)

### For Production:
1. **Docker + AWS/GCP** (scalable, professional)
2. **Azure App Service** (enterprise)

---

## 📞 Support

If you encounter issues:
1. Check logs for error messages
2. Verify all dependencies are installed
3. Ensure ports are open
4. Check resource limits

---

## ✅ Post-Deployment Checklist

- [ ] Application loads successfully
- [ ] Sample data loads correctly
- [ ] Classical solver runs
- [ ] Quantum solver runs
- [ ] Results display properly
- [ ] Route visualizations work
- [ ] Export functionality works
- [ ] Mobile responsive (if needed)
- [ ] SSL certificate configured
- [ ] Monitoring setup
- [ ] Backup strategy in place

---

**Need help?** Check the logs or contact support for your chosen platform.

**Your app is ready to deploy!** 🚀⚛️
