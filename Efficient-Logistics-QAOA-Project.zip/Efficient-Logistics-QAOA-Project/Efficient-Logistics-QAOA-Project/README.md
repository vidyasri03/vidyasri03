# Efficient Logistics Scheduling - QAOA Approach

A comprehensive pipeline that addresses supply chain optimization using both classical and quantum approaches. The system ingests supply-chain data, formulates logistics scheduling instances as QUBO problems, solves them using classical methods (OR-Tools) and quantum simulation (Qiskit QAOA), and presents comparative results through an interactive web interface.

## 🎯 Project Overview

This project demonstrates the application of Quantum Approximate Optimization Algorithm (QAOA) to real-world logistics problems, specifically the Traveling Salesman Problem (TSP). It provides:

- **Data Processing**: Transform supply chain datasets into optimization-ready formats
- **Classical Baseline**: OR-Tools based TSP solver for performance comparison
- **Quantum Simulation**: Qiskit QAOA implementation with configurable parameters
- **Visualization**: Interactive charts and network graphs for result analysis
- **Web Interface**: User-friendly frontend for running optimizations
- **REST API**: Backend service for programmatic access

## 🏗️ Architecture

```
┌─────────────────┐
│   Frontend      │  Streamlit/React UI
│   (Web UI)      │
└────────┬────────┘
         │ HTTP
┌────────▼────────┐
│   Backend API   │  FastAPI REST endpoints
│   (FastAPI)     │
└────────┬────────┘
         │
    ┌────┴────┐
    │         │
┌───▼──┐  ┌──▼────┐
│Classical│ │Quantum│  OR-Tools & Qiskit QAOA
│Solver  │ │Solver │
└───┬────┘ └──┬────┘
    │         │
┌───▼─────────▼───┐
│  Data Pipeline  │  Preprocessing & QUBO
│  & Visualization│
└─────────────────┘
```

## 📋 Prerequisites

- Python 3.10 or higher
- pip (Python package manager)
- Git
- (Optional) Docker for containerized deployment

## 🚀 Installation

### 1. Clone the repository

```bash
git clone <repository-url>
cd Efficient-Logistics-QAOA
```

### 2. Create virtual environment

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**Mac/Linux:**
```bash
python -m venv venv
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

## 📊 Usage

### Quick Start - Run Demo Script

```bash
# Run the complete pipeline demo
python demo.py
```

### Step-by-Step Usage

#### 1. Preprocess Data

```bash
python src/preprocessing/preprocess.py
```

This will:
- Load the supply chain dataset from `data/supply_chain_data.csv`
- Clean and validate the data
- Generate a cost matrix
- Save processed instance to `data/instance_small.csv`

#### 2. Run Classical Solver

```bash
python src/classical/ortools_solver.py
```

Output: Optimal route and total cost using OR-Tools

#### 3. Run Quantum Solver (QAOA)

```bash
python src/quantum/qiskit_qaoa.py
```

Output: QAOA solution with circuit depth and execution statistics

#### 4. Generate Visualizations

```bash
python src/viz/plots.py
```

Output: Heatmaps, route graphs, and comparison charts in `results/`

### Run Backend API

```bash
uvicorn src.api.main:app --reload --port 8000
```

API will be available at: `http://localhost:8000`

API Documentation: `http://localhost:8000/docs`

### Run Frontend (Streamlit)

```bash
streamlit run frontend/streamlit_app.py
```

Frontend will open in your browser at: `http://localhost:8501`

## 🧪 Testing

### Run all tests

```bash
pytest
```

### Run with coverage

```bash
pytest --cov=src --cov-report=html
```

### Run specific test categories

```bash
# Unit tests only
pytest tests/test_preprocessing.py tests/test_qubo.py

# Property-based tests only
pytest tests/test_properties.py

# API tests only
pytest tests/test_api.py
```

## 🐳 Docker Deployment

### Build and run with Docker Compose

```bash
docker-compose up --build
```

Services:
- Backend API: `http://localhost:8000`
- Frontend: `http://localhost:8501`

### Build Docker image manually

```bash
docker build -t logistics-qaoa-backend .
docker run -p 8000:8000 logistics-qaoa-backend
```

## 📁 Project Structure

```
Efficient-Logistics-QAOA/
├── data/                          # Data files
│   └── supply_chain_data.csv      # Input dataset
├── docs/                          # Documentation
│   └── slide.png                  # Project presentation
├── src/                           # Source code
│   ├── preprocessing/             # Data processing
│   │   └── preprocess.py
│   ├── qubo/                      # QUBO formulation
│   │   └── qubo_builder.py
│   ├── classical/                 # Classical solver
│   │   └── ortools_solver.py
│   ├── quantum/                   # Quantum solver
│   │   └── qiskit_qaoa.py
│   ├── viz/                       # Visualizations
│   │   └── plots.py
│   └── api/                       # Backend API
│       └── main.py
├── frontend/                      # Frontend application
│   └── streamlit_app.py
├── tests/                         # Test suite
│   ├── test_preprocessing.py
│   ├── test_qubo.py
│   ├── test_classical.py
│   ├── test_quantum.py
│   ├── test_api.py
│   └── test_properties.py
├── notebooks/                     # Jupyter notebooks
│   └── demo.ipynb
├── requirements.txt               # Python dependencies
├── Dockerfile                     # Docker configuration
├── docker-compose.yml             # Multi-container setup
└── README.md                      # This file
```

## 🔌 API Endpoints

### Status
- `GET /status` - Check API health

### Preprocessing
- `POST /api/preprocess` - Process supply chain dataset

### Solvers
- `POST /api/solve/classical` - Run OR-Tools TSP solver
- `POST /api/solve/quantum` - Run QAOA simulation

### Visualizations
- `GET /api/visualizations/{viz_type}` - Retrieve generated plots

### Comparison
- `POST /api/compare` - Compare classical vs quantum results

See full API documentation at `/docs` when running the server.

## 📈 Example Results

### Sample Output

```
Classical Solver (OR-Tools):
Route: [0, 2, 4, 1, 3, 0]
Cost: 245.8
Time: 0.12s

Quantum Solver (QAOA, p=1):
Route: [0, 2, 4, 1, 3, 0]
Cost: 245.8
Time: 2.34s
Circuit Depth: 1
```

## 🧑‍💻 Development

### Code Quality

```bash
# Format code
black src/ tests/

# Lint code
flake8 src/ tests/

# Type check
mypy src/
```

### Adding New Features

1. Update requirements in `.kiro/specs/logistics-qaoa-system/requirements.md`
2. Update design in `.kiro/specs/logistics-qaoa-system/design.md`
3. Add tasks to `.kiro/specs/logistics-qaoa-system/tasks.md`
4. Implement features with tests
5. Update documentation

## 📚 References

- [Qiskit Documentation](https://qiskit.org/documentation/)
- [OR-Tools Documentation](https://developers.google.com/optimization)
- [QAOA Tutorial](https://qiskit.org/textbook/ch-applications/qaoa.html)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)

## 👥 Team

This project is designed for a 3-person team working over 2 weeks:

**Week 1 - Phase 1 Baseline:**
- Member A: Data cleaning + QUBO builder
- Member B: OR-Tools solver + script integration
- Member C: Visualizations + notebook & README

**Week 2 - Phase 2 QAOA:**
- Member A: Qiskit QAOA implementation + parameter sweep
- Member B: Backend API integration (endpoints for runs)
- Member C: Frontend (Streamlit or React) + final visual polish

## 📝 License

[Add your license here]

## 🤝 Contributing

Contributions are welcome! Please read CONTRIBUTING.md for guidelines.

## 📧 Contact

[Add contact information]
