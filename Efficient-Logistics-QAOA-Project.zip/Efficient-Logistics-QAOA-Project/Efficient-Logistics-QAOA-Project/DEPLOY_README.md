# 🚀 Quick Deployment Guide

## Choose Your Deployment Method

### 🌟 Option 1: Streamlit Cloud (Easiest - 5 minutes)

**Best for**: Quick demos, sharing with others, free hosting

**Steps**:
1. Push code to GitHub:
   ```bash
   git add .
   git commit -m "Deploy to Streamlit Cloud"
   git push origin main
   ```

2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Sign in with GitHub
4. Click "New app"
5. Select your repository
6. Set main file: `frontend/streamlit_app.py`
7. Click "Deploy"

**Done!** Your app will be live at: `https://YOUR_USERNAME-YOUR_REPO.streamlit.app`

---

### 🐳 Option 2: Docker (Local - 10 minutes)

**Best for**: Local testing, development, full control

**Prerequisites**: Docker Desktop installed

**Steps**:

**Windows**:
```bash
# Run the deployment script
deploy.bat
# Select option 2
```

**Mac/Linux**:
```bash
# Make script executable
chmod +x deploy.sh

# Run the deployment script
./deploy.sh
# Select option 3
```

**Or manually**:
```bash
# Build image
docker build -f Dockerfile.streamlit -t quantum-logistics:latest .

# Run container
docker run -d -p 8501:8501 --name quantum-app quantum-logistics:latest

# Access at http://localhost:8501
```

---

### ☁️ Option 3: Heroku (15 minutes)

**Best for**: Production apps, custom domain, scaling

**Prerequisites**: 
- Heroku account
- Heroku CLI installed

**Steps**:
```bash
# Login to Heroku
heroku login

# Create app
heroku create your-app-name

# Deploy
git push heroku main

# Open app
heroku open
```

---

### 🖥️ Option 4: AWS EC2 (30 minutes)

**Best for**: Enterprise, full control, custom configuration

**Quick Setup**:
1. Launch Ubuntu EC2 instance (t2.medium)
2. Allow ports 22 and 8501 in security group
3. SSH into instance:
   ```bash
   ssh -i your-key.pem ubuntu@your-ec2-ip
   ```
4. Install and run:
   ```bash
   sudo apt update && sudo apt install python3-pip python3-venv git -y
   git clone YOUR_REPO_URL
   cd YOUR_REPO
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   streamlit run frontend/streamlit_app.py --server.port=8501 --server.address=0.0.0.0
   ```
5. Access at: `http://your-ec2-ip:8501`

---

## 📋 Pre-Deployment Checklist

Before deploying, ensure:

- [ ] All dependencies in `requirements.txt`
- [ ] `.streamlit/config.toml` exists
- [ ] `packages.txt` exists (for Streamlit Cloud)
- [ ] Code pushed to GitHub (for cloud deployments)
- [ ] Environment variables configured (if needed)
- [ ] Data files included in repository

---

## 🔧 Configuration Files

All necessary files are already created:

✅ `.streamlit/config.toml` - Streamlit configuration
✅ `packages.txt` - System dependencies
✅ `Procfile` - Heroku configuration
✅ `setup.sh` - Heroku setup script
✅ `runtime.txt` - Python version
✅ `Dockerfile.streamlit` - Docker configuration
✅ `docker-compose.yml` - Docker Compose setup

---

## 🎯 Recommended Deployment Path

### For Quick Demo:
**→ Streamlit Cloud** (Free, 5 minutes)

### For Development:
**→ Docker Local** (Full control, instant)

### For Production:
**→ Heroku or AWS** (Scalable, professional)

---

## 📊 Platform Comparison

| Platform | Cost | Setup Time | Difficulty | Best For |
|----------|------|------------|------------|----------|
| **Streamlit Cloud** | Free | 5 min | ⭐ Easy | Demos, prototypes |
| **Docker Local** | Free | 10 min | ⭐⭐ Medium | Development |
| **Heroku** | $7/mo | 15 min | ⭐⭐ Medium | Small production apps |
| **AWS EC2** | $20/mo | 30 min | ⭐⭐⭐⭐ Hard | Enterprise, scaling |

---

## 🆘 Troubleshooting

### Issue: Dependencies fail to install
**Solution**: Check Python version (3.9+ required)

### Issue: Port already in use
**Solution**: 
```bash
# Find process using port 8501
netstat -ano | findstr :8501  # Windows
lsof -i :8501                 # Mac/Linux

# Kill the process or use different port
streamlit run frontend/streamlit_app.py --server.port=8502
```

### Issue: Docker build fails
**Solution**: Ensure Docker Desktop is running and has enough resources (4GB RAM minimum)

### Issue: Streamlit Cloud deployment fails
**Solution**: 
- Check `requirements.txt` for incompatible versions
- Ensure `packages.txt` includes system dependencies
- Verify main file path is correct

---

## 📖 Detailed Documentation

For comprehensive deployment instructions, see:
- **DEPLOYMENT_GUIDE.md** - Complete guide for all platforms
- **INSTALLATION.md** - Local setup instructions
- **QUICKSTART.md** - Getting started guide

---

## 🎉 Post-Deployment

After deployment, test your app:

1. ✅ Load sample data
2. ✅ Run classical solver
3. ✅ Run quantum solver
4. ✅ View results and visualizations
5. ✅ Export results

---

## 🔗 Useful Links

- [Streamlit Cloud](https://share.streamlit.io)
- [Heroku](https://www.heroku.com)
- [Docker Hub](https://hub.docker.com)
- [AWS EC2](https://aws.amazon.com/ec2)

---

## 💡 Tips

1. **Start with Streamlit Cloud** - It's the easiest way to get started
2. **Use Docker for local testing** - Before deploying to cloud
3. **Monitor your app** - Check logs regularly
4. **Keep dependencies updated** - Run `pip list --outdated`
5. **Backup your data** - Especially for production deployments

---

## 🚀 Ready to Deploy?

Choose your platform and follow the steps above. Your Quantum Logistics Optimizer will be live in minutes!

**Need help?** Check the detailed guides or open an issue on GitHub.

---

**Happy Deploying!** 🎯⚛️
