# 📦 Installation & Deployment Guide

Complete guide for installing and deploying Efficient Logistics Scheduling.

## Table of Contents

1. [System Requirements](#system-requirements)
2. [Local Installation](#local-installation)
3. [Docker Deployment](#docker-deployment)
4. [Cloud Deployment](#cloud-deployment)
5. [Troubleshooting](#troubleshooting)
6. [Configuration](#configuration)

## System Requirements

### Minimum Requirements
- **OS**: Windows 10/11, macOS 10.15+, or Linux (Ubuntu 20.04+)
- **Python**: 3.10 or higher
- **RAM**: 4 GB
- **Disk Space**: 2 GB free
- **Internet**: Required for package installation

### Recommended Requirements
- **RAM**: 8 GB or more
- **CPU**: Multi-core processor
- **Disk Space**: 5 GB free

## Local Installation

### Step 1: Install Python

**Windows:**
1. Download Python 3.10+ from [python.org](https://www.python.org/downloads/)
2. Run installer, check "Add Python to PATH"
3. Verify: `python --version`

**macOS:**
```bash
# Using Homebrew
brew install python@3.10

# Verify
python3 --version
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install python3.10 python3.10-venv python3-pip

# Verify
python3 --version
```

### Step 2: Clone Repository

```bash
git clone <repository-url>
cd Efficient-Logistics-QAOA
```

### Step 3: Create Virtual Environment

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**macOS/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

You should see `(venv)` in your terminal prompt.

### Step 4: Install Dependencies

```bash
# Upgrade pip
python -m pip install --upgrade pip

# Install requirements
pip install -r requirements.txt
```

This will install:
- Qiskit (quantum computing)
- OR-Tools (classical optimization)
- FastAPI (backend API)
- Streamlit (frontend)
- Visualization libraries
- Testing frameworks

**Installation time**: 5-10 minutes depending on internet speed.

### Step 5: Verify Installation

```bash
# Run tests
pytest tests/test_preprocessing.py -v

# If tests pass, installation is successful!
```

### Step 6: Run Demo

```bash
python demo.py
```

You should see output showing:
- ✅ Data preprocessing
- ✅ QUBO building
- ✅ Classical solving
- ✅ Quantum solving
- ✅ Visualization generation

## Docker Deployment

### Prerequisites

Install Docker:
- **Windows/Mac**: [Docker Desktop](https://www.docker.com/products/docker-desktop)
- **Linux**: [Docker Engine](https://docs.docker.com/engine/install/)

Verify installation:
```bash
docker --version
docker-compose --version
```

### Option 1: Docker Compose (Recommended)

**Build and run all services:**
```bash
docker-compose up --build
```

**Run in background:**
```bash
docker-compose up -d
```

**View logs:**
```bash
docker-compose logs -f
```

**Stop services:**
```bash
docker-compose down
```

**Access services:**
- Frontend: http://localhost:8501
- Backend API: http://localhost:8000
- API Docs: http://localhost:8000/docs

### Option 2: Individual Containers

**Build backend:**
```bash
docker build -t logistics-backend .
```

**Run backend:**
```bash
docker run -p 8000:8000 \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/results:/app/results \
  logistics-backend
```

**Build frontend:**
```bash
docker build -f Dockerfile.streamlit -t logistics-frontend .
```

**Run frontend:**
```bash
docker run -p 8501:8501 \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/results:/app/results \
  logistics-frontend
```

### Docker Tips

**View running containers:**
```bash
docker ps
```

**Stop all containers:**
```bash
docker stop $(docker ps -q)
```

**Remove all containers:**
```bash
docker rm $(docker ps -aq)
```

**Clean up images:**
```bash
docker system prune -a
```

## Cloud Deployment

### Heroku Deployment

**Prerequisites:**
- Heroku account
- Heroku CLI installed

**Steps:**

1. **Create Heroku app:**
```bash
heroku create logistics-qaoa-app
```

2. **Add buildpack:**
```bash
heroku buildpacks:set heroku/python
```

3. **Create Procfile:**
```
web: uvicorn src.api.main:app --host 0.0.0.0 --port $PORT
```

4. **Deploy:**
```bash
git push heroku main
```

5. **Open app:**
```bash
heroku open
```

### AWS Deployment

**Using AWS Elastic Beanstalk:**

1. **Install EB CLI:**
```bash
pip install awsebcli
```

2. **Initialize:**
```bash
eb init -p python-3.10 logistics-qaoa
```

3. **Create environment:**
```bash
eb create logistics-env
```

4. **Deploy:**
```bash
eb deploy
```

5. **Open:**
```bash
eb open
```

### Google Cloud Platform

**Using Cloud Run:**

1. **Build container:**
```bash
gcloud builds submit --tag gcr.io/PROJECT_ID/logistics-qaoa
```

2. **Deploy:**
```bash
gcloud run deploy logistics-qaoa \
  --image gcr.io/PROJECT_ID/logistics-qaoa \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated
```

## Troubleshooting

### Common Issues

#### 1. Import Errors

**Problem:** `ModuleNotFoundError: No module named 'qiskit'`

**Solution:**
```bash
# Ensure virtual environment is activated
source venv/bin/activate  # or venv\Scripts\activate on Windows

# Reinstall requirements
pip install -r requirements.txt
```

#### 2. OR-Tools Installation Fails

**Problem:** OR-Tools won't install

**Solution:**
```bash
# Try with no cache
pip install ortools --no-cache-dir

# Or install specific version
pip install ortools==9.7.2996
```

#### 3. Qiskit Installation Issues

**Problem:** Qiskit installation fails or takes too long

**Solution:**
```bash
# Install core packages separately
pip install qiskit --no-cache-dir
pip install qiskit-optimization --no-cache-dir
pip install qiskit-aer --no-cache-dir
```

#### 4. Port Already in Use

**Problem:** `Address already in use: 8000` or `8501`

**Solution:**
```bash
# Find process using port
# Windows:
netstat -ano | findstr :8000

# Mac/Linux:
lsof -i :8000

# Kill process or use different port
uvicorn src.api.main:app --port 8001
streamlit run frontend/streamlit_app.py --server.port 8502
```

#### 5. Memory Issues with QAOA

**Problem:** QAOA runs out of memory

**Solution:**
- Reduce problem size (max_nodes parameter)
- Reduce circuit depth (reps parameter)
- Reduce shots (shots parameter)
- Use smaller instances for testing

#### 6. Docker Build Fails

**Problem:** Docker build errors

**Solution:**
```bash
# Clean Docker cache
docker system prune -a

# Rebuild without cache
docker-compose build --no-cache

# Check Docker resources (increase if needed)
# Docker Desktop → Settings → Resources
```

### Getting Help

If you encounter issues:

1. **Check logs:**
   ```bash
   # Application logs
   tail -f logs/app.log
   
   # Docker logs
   docker-compose logs -f
   ```

2. **Verify environment:**
   ```bash
   python --version
   pip list
   ```

3. **Run diagnostics:**
   ```bash
   python -c "import qiskit; print(qiskit.__version__)"
   python -c "import ortools; print('OR-Tools OK')"
   ```

4. **Check GitHub Issues**

5. **Open new issue with:**
   - Error message
   - Python version
   - OS version
   - Steps to reproduce

## Configuration

### Environment Variables

Create `.env` file:

```bash
# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
API_RELOAD=true

# QAOA Parameters
QAOA_DEFAULT_REPS=1
QAOA_DEFAULT_SHOTS=1024
QAOA_MAX_ITER=100

# Solver Timeouts
CLASSICAL_SOLVER_TIMEOUT=30
QUANTUM_SOLVER_TIMEOUT=300

# File Upload
MAX_UPLOAD_SIZE_MB=10
MAX_NODES=20

# Logging
LOG_LEVEL=INFO
```

### Custom Configuration

**Modify solver parameters:**

Edit `src/api/main.py`:
```python
# Change default QAOA parameters
DEFAULT_REPS = 2
DEFAULT_SHOTS = 2048

# Change penalty weights
PENALTY_A = 1000
PENALTY_B = 1000
```

**Modify frontend styling:**

Edit `frontend/streamlit_app.py`:
```python
# Change color scheme
PRIMARY_COLOR = "#2E86AB"
SECONDARY_COLOR = "#A23B72"
```

## Performance Optimization

### For Development

```bash
# Use smaller instances
max_nodes = 5

# Reduce QAOA parameters
reps = 1
shots = 512
```

### For Production

```bash
# Enable caching
pip install redis
# Configure Redis caching in API

# Use production WSGI server
pip install gunicorn
gunicorn src.api.main:app -w 4 -k uvicorn.workers.UvicornWorker
```

### Database Integration (Optional)

For persistent storage:

```bash
# Install PostgreSQL adapter
pip install psycopg2-binary sqlalchemy

# Configure database URL
DATABASE_URL=postgresql://user:pass@localhost/logistics
```

## Security Considerations

### For Production Deployment

1. **Enable HTTPS:**
   - Use reverse proxy (Nginx)
   - Configure SSL certificates

2. **Add Authentication:**
   - Implement JWT tokens
   - Add user management

3. **Configure CORS:**
   - Specify allowed origins
   - Remove wildcard (`*`)

4. **Set Rate Limiting:**
   - Limit requests per IP
   - Implement API keys

5. **Secure Environment Variables:**
   - Use secrets management
   - Never commit `.env` files

## Monitoring

### Application Monitoring

```bash
# Install monitoring tools
pip install prometheus-client

# Add health check endpoint
# Already included: GET /status
```

### Docker Monitoring

```bash
# View resource usage
docker stats

# View container health
docker ps --format "table {{.Names}}\t{{.Status}}"
```

## Backup and Recovery

### Backup Data

```bash
# Backup data directory
tar -czf backup-$(date +%Y%m%d).tar.gz data/ results/

# Backup database (if using)
pg_dump logistics > backup.sql
```

### Restore Data

```bash
# Restore from backup
tar -xzf backup-20240101.tar.gz

# Restore database
psql logistics < backup.sql
```

## Updating

### Update Dependencies

```bash
# Update all packages
pip install --upgrade -r requirements.txt

# Update specific package
pip install --upgrade qiskit
```

### Update Application

```bash
# Pull latest changes
git pull origin main

# Reinstall dependencies
pip install -r requirements.txt

# Restart services
docker-compose restart
```

---

**Installation complete! Ready to optimize your supply chain!** 🚚⚛️

For quick start instructions, see [QUICKSTART.md](QUICKSTART.md)
