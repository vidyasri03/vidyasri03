# 🚀 Quick Start Guide

Get up and running with Efficient Logistics Scheduling in 5 minutes!

## Prerequisites

- Python 3.10 or higher
- pip (Python package manager)
- Git

## Installation

### 1. Clone the Repository

```bash
git clone <repository-url>
cd Efficient-Logistics-QAOA
```

### 2. Create Virtual Environment

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**Mac/Linux:**
```bash
python -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

## Running the Demo

### Option 1: Complete Demo Script

Run the full pipeline demonstration:

```bash
python demo.py
```

This will:
- ✅ Preprocess sample data
- ✅ Build QUBO matrix
- ✅ Solve with OR-Tools (classical)
- ✅ Solve with QAOA (quantum)
- ✅ Generate visualizations

### Option 2: Streamlit Web Interface

Launch the interactive web application:

```bash
streamlit run frontend/streamlit_app.py
```

Then open your browser to: `http://localhost:8501`

### Option 3: REST API

Start the FastAPI backend:

```bash
uvicorn src.api.main:app --reload --port 8000
```

API documentation available at: `http://localhost:8000/docs`

## Using Docker

### Build and Run with Docker Compose

```bash
docker-compose up --build
```

Services will be available at:
- **Frontend**: http://localhost:8501
- **Backend API**: http://localhost:8000

## Step-by-Step Usage

### 1. Preprocess Data

```bash
python src/preprocessing/preprocess.py
```

### 2. Build QUBO

```bash
python src/qubo/qubo_builder.py
```

### 3. Solve Classically

```bash
python src/classical/ortools_solver.py
```

### 4. Solve with QAOA

```bash
python src/quantum/qiskit_qaoa.py
```

### 5. Generate Visualizations

```bash
python src/viz/plots.py
```

## Testing

Run all tests:

```bash
pytest
```

Run specific test categories:

```bash
# Unit tests only
pytest tests/test_preprocessing.py tests/test_qubo.py tests/test_classical.py

# Property-based tests
pytest tests/test_properties.py -m property

# API tests
pytest tests/test_api.py
```

## Troubleshooting

### Import Errors

If you see import errors, make sure you're in the project root directory and your virtual environment is activated.

### OR-Tools Installation Issues

If OR-Tools fails to install:

```bash
pip install --upgrade pip
pip install ortools --no-cache-dir
```

### Qiskit Installation Issues

If Qiskit fails to install:

```bash
pip install qiskit qiskit-optimization qiskit-aer --no-cache-dir
```

### Memory Issues with QAOA

For large problem instances, QAOA simulation may require significant memory. Try:
- Reducing the number of nodes (max_nodes parameter)
- Reducing circuit depth (reps parameter)
- Reducing shots (shots parameter)

## Next Steps

1. **Explore the Web Interface**: Upload your own supply chain data
2. **Experiment with Parameters**: Try different QAOA circuit depths
3. **Compare Results**: Analyze classical vs quantum performance
4. **Read the Documentation**: Check out the full README.md

## Getting Help

- 📖 Full documentation: See README.md
- 🐛 Issues: Report bugs on GitHub
- 💬 Questions: Open a discussion

## Quick Reference

### Key Files

- `demo.py` - Complete demonstration script
- `frontend/streamlit_app.py` - Web interface
- `src/api/main.py` - REST API
- `data/supply_chain_data.csv` - Sample dataset
- `requirements.txt` - Python dependencies

### Key Commands

```bash
# Run demo
python demo.py

# Start web app
streamlit run frontend/streamlit_app.py

# Start API
uvicorn src.api.main:app --reload

# Run tests
pytest

# Docker
docker-compose up
```

---

**Ready to optimize your supply chain with quantum computing!** 🚚⚛️
