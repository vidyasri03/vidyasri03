# 🚀 Deployment Quick Reference Card

## ⚡ 30-Second Deployment

### Streamlit Cloud (Easiest)
```bash
git add . && git commit -m "Deploy" && git push
# Then: share.streamlit.io → New app → Deploy
```

### Docker (Fastest Local)
```bash
docker build -f Dockerfile.streamlit -t quantum-logistics . && docker run -p 8501:8501 quantum-logistics
```

### Heroku (One Command)
```bash
heroku create my-app && git push heroku main && heroku open
```

---

## 📋 Platform Cheat Sheet

| Platform | Command | Time | Cost |
|----------|---------|------|------|
| **Streamlit Cloud** | `git push` → Web UI | 5 min | Free |
| **Docker** | `docker run` | 2 min | Free |
| **Heroku** | `git push heroku` | 10 min | $7/mo |
| **AWS EC2** | SSH + setup | 30 min | $20/mo |

---

## 🔧 Essential Commands

### Check Status
```bash
# Local
curl http://localhost:8501

# Heroku
heroku ps

# Docker
docker ps
```

### View Logs
```bash
# Local
streamlit run frontend/streamlit_app.py

# Heroku
heroku logs --tail

# Docker
docker logs quantum-app
```

### Restart
```bash
# Heroku
heroku restart

# Docker
docker restart quantum-app
```

---

## 🎯 Quick Troubleshooting

| Problem | Solution |
|---------|----------|
| Port in use | Change port: `--server.port=8502` |
| Module not found | Add to `requirements.txt` |
| Build fails | Check Python version (3.9+) |
| Memory error | Upgrade instance size |

---

## 📁 Required Files

✅ `.streamlit/config.toml`
✅ `packages.txt`
✅ `requirements.txt`
✅ `Procfile` (Heroku)
✅ `runtime.txt` (Heroku)

---

## 🌐 Access URLs

- **Local**: http://localhost:8501
- **Streamlit Cloud**: https://USERNAME-REPO.streamlit.app
- **Heroku**: https://APP-NAME.herokuapp.com
- **AWS**: http://EC2-IP:8501

---

## 💡 Pro Tips

1. **Test locally first**: `streamlit run frontend/streamlit_app.py`
2. **Use Docker for consistency**: Same environment everywhere
3. **Start with Streamlit Cloud**: Free and easy
4. **Monitor logs**: Catch errors early
5. **Keep dependencies minimal**: Faster builds

---

## 🆘 Emergency Commands

```bash
# Stop everything
docker stop $(docker ps -q)
heroku ps:stop web

# Clean restart
docker system prune -a
heroku restart

# Check health
curl -I http://localhost:8501
```

---

## 📞 Get Help

- **Docs**: DEPLOYMENT_GUIDE.md
- **Quick Start**: DEPLOY_README.md
- **Scripts**: deploy.sh / deploy.bat

---

**Ready? Pick a platform and deploy!** 🚀
